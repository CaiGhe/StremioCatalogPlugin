# Stremio/Nuvio Catalog Đa Quốc Gia (Static, không stream)

Static addon cho Stremio/Nuvio — 16 catalog phim theo quốc gia, poster + mô tả
tiếng Việt. Không chứa link stream, chỉ metadata. Host miễn phí trên GitHub Pages.

## 1. Cài đặt

```bash
npm install    # không có dependency ngoài, chỉ để chắc chắn môi trường ổn
cp .env.example .env
```

Mở `.env`, điền `TMDB_API_KEY` (đăng ký miễn phí tại
https://www.themoviedb.org/settings/api). Không có key vẫn chạy được, nhưng
3 nhóm catalog `anime-*`, `kids-*`, `docs-*` sẽ trống vì lấy dữ liệu chính từ TMDB.

## 2. Chạy

```bash
npm run fetch          # gọi API, ghi dữ liệu vào cache/*.json (idempotent — chạy lại không trùng)
npm run build          # xuất public/manifest.json + public/catalog/**/*.json
npm run verify         # chạy checklist kiểm tra (xem mục 5)
npm test               # test offline logic parse bằng fixture thật, không cần mạng
```

Lần đầu chạy, dùng `npm run fetch -- --debug` (hoặc `node scripts/fetch.js --debug`)
để in ra 1 mẫu dữ liệu mỗi catalog — **đặc biệt kiểm tra link poster in ra có mở
được không** (xem mục 4, có 1 chỗ tao đoán domain ảnh CDN).

`fetch` chạy khá lâu (rate-limit 300-500ms/request, gọi chi tiết từng phim +
TMDB) — bình thường, đừng Ctrl+C giữa chừng vì cache là idempotent, chạy lại
bao nhiêu lần cũng an toàn (ghi đè theo IMDb ID, không tạo trùng).

## 3. Deploy GitHub Pages

### Cách A — Có máy tính, chạy tay 1 lần

```bash
# Sau khi đã có thư mục public/ (từ npm run build):
git init
git add -A
git commit -m "Stremio catalog đa quốc gia"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```

Vào **Settings → Pages** trên GitHub repo → Source chọn branch `main`,
folder chọn `/public` (hoặc `/docs` nếu bạn đổi tên thư mục output).

> Lưu ý: `.gitignore` đang loại `public/manifest.json` và `public/catalog/` ra
> khỏi git (vì mặc định coi đây là build output, tự build lại trên máy deploy).
> Nếu bạn deploy kiểu "build 1 lần rồi commit thẳng public/", **xoá 2 dòng cuối
> trong `.gitignore`** trước khi `git add`.

### Cách B — Chỉ có điện thoại, không cần cài gì, không cần bung file

Không cần giải nén, không cần upload nhiều file/folder (rất dễ thiếu sót khi
làm qua trình duyệt điện thoại). Chỉ 2 file cần đưa lên GitHub: file zip
nguyên bản + 1 file workflow (copy-paste text, không cần upload).

1. Vào github.com bằng trình duyệt điện thoại → tạo repo mới (trống).
2. Trên trang repo → **Add file → Create new file**. Đặt tên file:
   `.github/workflows/update-catalog.yml` (gõ luôn dấu `/`, GitHub tự tạo
   folder). Mở file `update-catalog.yml` trong zip bạn vừa tải, copy toàn bộ
   nội dung, dán vào ô soạn thảo trên GitHub → Commit.
3. Vẫn trên trang repo → **Add file → Upload files** → chọn đúng **file zip**
   gốc (không cần giải nén) → Commit. Workflow tự nhận diện và giải nén khi chạy.
4. **Settings → Secrets and variables → Actions → New repository secret** →
   tên `TMDB_API_KEY`, giá trị là key TMDB của bạn.
5. **Settings → Pages** → Source chọn **"GitHub Actions"**.
6. Tab **Actions** → chọn "Update Catalog & Deploy" → **Run workflow**. Chờ
   vài phút, xong addon có ở `https://<username>.github.io/<repo>/manifest.json`.

Workflow cũng tự chạy lại mỗi ngày (01:00 sáng giờ VN) để cập nhật phim mới.

## 4. Cài vào Stremio / Nuvio

**Stremio:** mở app → biểu tượng addon (mảnh ghép) → dán URL
`https://<username>.github.io/<repo>/manifest.json` vào ô "Addon Repository URL"
→ Install. 16 catalog sẽ xuất hiện trên trang chủ, mỗi cái là 1 hàng ngang.

**Nuvio:** vào phần Addons/Repository trong app, dán cùng URL manifest.json.
Vì đây là static JSON tuân đúng giao thức Stremio addon, Nuvio đọc được y hệt.

## 5. Checklist đã tự kiểm tra + việc bạn cần làm

Đã verify khi build code này:

- ✅ Test offline (`npm test`) parse đúng response **thật** của KKPhim (dùng
  fixture chụp từ tài liệu chính thức `kkphim.com/api-document`, không phải suy đoán)
- ✅ `build.js` cảnh báo rõ nếu catalog nào <10 phim
- ✅ `manifest.json` được validate cấu trúc cơ bản (đủ field bắt buộc theo giao
  thức Stremio) trong `verify.js`
- ✅ Toàn bộ JSON ghi bằng `JSON.stringify` — không thể có trailing comma / lỗi cú pháp
- ✅ Cách lấy IMDb ID từ TMDB ID đã sửa lại cho đúng: dùng
  `/movie|tv/{id}?append_to_response=external_ids` (yêu cầu gốc ghi
  `/find/{tmdb_id}?external_source=tmdb_id` — **endpoint đó không tồn tại**
  trên TMDB, `/find` chỉ nhận imdb_id/tvdb_id làm input, không có chiều ngược lại)

**Còn 2 điểm chưa tự verify được (do sandbox code không ra được mạng ngoài
npm/pypi/github, và trang docs NguonC chặn bot) — cần bạn chạy `npm run
fetch:debug` một lần và kiểm tra:**

1. **Domain ảnh CDN của KKPhim** (`config/sources.js` → `kkphim.imageBaseUrl`,
   đang đặt mặc định `https://phimimg.com/`). Chạy debug, copy link poster in
   ra, mở thử trên trình duyệt. Nếu ảnh vỡ, đổi đúng 1 dòng này.
2. **Tên field response của NguonC** (`config/sources.js` → object `nguonc`).
   Trang `phim.nguonc.com/api-document` chặn truy cập tự động nên phần này
   code theo đúng mô tả gốc bạn cung cấp, có dò thêm vài biến thể tên field phổ
   biến để tăng khả năng chạy đúng ngay. Nếu log báo `[warn][nguonc]` liên tục
   khi fetch, nghĩa là tên field thật khác — mở docs trên máy bạn, sửa lại
   object `fields` trong `config/sources.js`, không cần đụng
   `src/clients/nguonc.js`. **Quan trọng: nếu NguonC lỗi hoàn toàn, catalog vẫn
   ra được bình thường chỉ với KKPhim** — đúng yêu cầu "nguồn chết → log cảnh
   báo, bỏ qua, catalog vẫn xuất từ nguồn còn lại".

## 6. Kiến trúc / sửa ở đâu khi cần

```
config/sources.js    <- TOÀN BỘ url + tên field của KKPhim/NguonC/TMDB/Cinemeta
config/catalogs.js   <- danh sách 16 catalog, thêm/bớt/đổi ở đây
src/clients/*.js     <- logic gọi từng nguồn (không nên cần sửa nếu API không đổi)
src/dedupe.js        <- quy tắc gộp trùng theo IMDb ID
src/normalize.js     <- chuyển candidate -> Stremio meta object
scripts/fetch.js     <- orchestrator chính, sửa nếu muốn đổi chiến lược fetch
scripts/build.js     <- xuất file tĩnh
scripts/verify.js    <- checklist kiểm tra
```

Nếu KKPhim hoặc NguonC đổi API trong tương lai: 90% trường hợp chỉ cần sửa
`config/sources.js`, không đụng code logic.

## 7. Giới hạn đã biết

- Chỉ giữ phim có IMDb ID thật (`tt...`) — phim không tra ra được IMDb ID (vì
  thiếu `tmdb.id` ở KKPhim, hoặc TMDB không trả `external_ids.imdb_id`) sẽ bị
  loại khỏi catalog, đúng yêu cầu.
- `kids-movie`/`kids-series` loại phim gốc tiếng Nhật (để không trùng với
  `anime-*`) bằng cách lọc `original_language !== 'ja'` sau khi nhận kết quả
  từ TMDB (TMDB discover không có tham số "loại trừ ngôn ngữ gốc" đáng tin cậy,
  nên lọc phía code cho chắc).
- Mỗi catalog giới hạn theo `ITEMS_PER_CATALOG` trong `.env` (mặc định 50).
