// test/normalize.test.js
//
// Test offline bằng fixture JSON THẬT (chụp trực tiếp từ tài liệu KKPhim, 2026-09).
// Mục đích: kiểm chứng logic parse trong src/clients/kkphim.js đọc đúng field
// thật của API, mà KHÔNG cần mạng ra ngoài (sandbox dev có thể không có mạng
// tới phimapi.com/phim.nguonc.com/api.themoviedb.org).
//
// Chạy: npm test

const assert = require('assert');
const fs = require('fs');
const path = require('path');

function loadFixture(name) {
  return JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', name), 'utf8'));
}

const originalFetch = global.fetch;

async function withMockFetch(responseMap, fn) {
  global.fetch = async (url) => {
    const matchKey = Object.keys(responseMap).find((key) => String(url).includes(key));
    if (!matchKey) throw new Error(`Không có fixture mock cho URL: ${url}`);
    const body = responseMap[matchKey];
    return { ok: true, status: 200, statusText: 'OK', json: async () => body };
  };
  try {
    await fn();
  } finally {
    global.fetch = originalFetch;
  }
}

async function testKkphimDetail() {
  delete require.cache[require.resolve('../src/clients/kkphim')];
  const kkphim = require('../src/clients/kkphim');
  const fixture = loadFixture('kkphim-detail-lightyear.json');

  await withMockFetch({ '/phim/lightyear-canh-sat-vu-tru': fixture }, async () => {
    const detail = await kkphim.getDetail('lightyear-canh-sat-vu-tru');
    assert.strictEqual(detail.name, 'Lightyear: Cảnh Sát Vũ Trụ');
    assert.strictEqual(detail.tmdbId, '718789');
    assert.strictEqual(detail.tmdbType, 'movie');
    assert.ok(detail.content.length > 10 && !detail.content.includes('<p>'), 'content phải được strip HTML');
    assert.ok(detail.poster.startsWith('https://phimimg.com/'), 'poster phải được resolve qua imageBaseUrl');
    assert.deepStrictEqual(detail.categories, ['Khoa Học']);
    assert.deepStrictEqual(detail.countries, ['Âu Mỹ']);
    console.log('  OK: kkphim.getDetail() parse đúng field từ response thật');
  });
}

async function testKkphimCountries() {
  delete require.cache[require.resolve('../src/clients/kkphim')];
  const kkphim = require('../src/clients/kkphim');
  const fixture = loadFixture('kkphim-countries.json');

  await withMockFetch({ '/quoc-gia': fixture }, async () => {
    const list = await kkphim.listCountries();
    assert.strictEqual(list.length, 2);
    assert.strictEqual(list[1].slug, 'au-my');
    console.log('  OK: kkphim.listCountries() parse đúng');
  });
}

async function testKkphimListByType() {
  delete require.cache[require.resolve('../src/clients/kkphim')];
  const kkphim = require('../src/clients/kkphim');
  const fixture = loadFixture('kkphim-danhsach-list.json');

  await withMockFetch({ '/v1/api/danh-sach/hoathinh': fixture }, async () => {
    const list = await kkphim.listByTypeAndCountry('hoathinh', 'au-my', { page: 1 });
    assert.strictEqual(list.length, 1);
    assert.strictEqual(list[0].slug, 'lightyear-canh-sat-vu-tru');
    console.log('  OK: kkphim.listByTypeAndCountry() parse đúng (lưu ý: KHÔNG có field content ở đây — đúng như thực tế)');
    assert.strictEqual(list[0].content, undefined, 'response danh sách thật sự không có content, phải gọi getDetail() riêng');
  });
}

async function testDedupeAndNormalize() {
  const { dedupeByImdb } = require('../src/dedupe');
  const { toStremioMeta } = require('../src/normalize');

  const candidates = [
    { source: 'tmdb', imdbId: 'tt1234567', name: 'Ten TMDB', content: 'Mo ta ngan', poster: null },
    { source: 'kkphim', imdbId: 'tt1234567', name: 'Tên KKPhim', content: 'Mô tả tiếng Việt đầy đủ và chi tiết hơn nhiều.', poster: 'https://phimimg.com/x.jpg' },
    { source: 'tmdb', imdbId: null, name: 'Không có IMDb -> phải bị loại' },
  ];

  const deduped = dedupeByImdb(candidates);
  assert.strictEqual(deduped.length, 1, 'phải gộp về đúng 1 bản ghi theo imdbId, bỏ candidate không có imdbId');
  assert.strictEqual(deduped[0].source, 'kkphim', 'phải ưu tiên bản có mô tả tiếng Việt tốt hơn');

  const meta = toStremioMeta(deduped[0], 'movie');
  assert.strictEqual(meta.id, 'tt1234567');
  assert.strictEqual(meta.type, 'movie');
  console.log('  OK: dedupe + normalize hoạt động đúng, ưu tiên nguồn tiếng Việt');
}

async function run() {
  console.log('== Test offline (dùng fixture thật, không cần mạng) ==');
  await testKkphimDetail();
  await testKkphimCountries();
  await testKkphimListByType();
  await testDedupeAndNormalize();
  console.log('\nTất cả test PASS.');
}

run().catch((err) => {
  console.error('\nTEST FAIL:', err);
  process.exit(1);
});
