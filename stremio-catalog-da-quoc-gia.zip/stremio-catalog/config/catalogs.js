// config/catalogs.js
//
// Định nghĩa 16 catalog. Đây là "bảng điều khiển" chính — muốn thêm/bớt/đổi
// catalog thì sửa Ở ĐÂY, không cần đụng scripts/fetch.js hay scripts/build.js.
//
// strategy:
//   'country'     -> lấy từ KKPhim (bắt buộc) + NguonC (nếu có), lọc theo quốc gia
//   'tmdb'        -> lấy hoàn toàn từ TMDB discover
//   'tmdb+kkphim' -> lấy từ TMDB, bổ sung thêm từ KKPhim (loại hoathinh)

const sources = require('./sources');

module.exports = [
  // ---- Việt Nam ----
  { id: 'viet-movie', name: '🇻🇳 Phim Lẻ Việt Nam', contentKind: 'movie', strategy: 'country', country: 'viet-nam', kkphimType: sources.kkphim.types.movie },
  { id: 'viet-series', name: '🇻🇳 Phim Bộ Việt Nam', contentKind: 'series', strategy: 'country', country: 'viet-nam', kkphimType: sources.kkphim.types.series },

  // ---- Hàn Quốc ----
  { id: 'korea-movie', name: '🇰🇷 Phim Lẻ Hàn Quốc', contentKind: 'movie', strategy: 'country', country: 'han-quoc', kkphimType: sources.kkphim.types.movie },
  { id: 'korea-series', name: '🇰🇷 Phim Bộ Hàn Quốc', contentKind: 'series', strategy: 'country', country: 'han-quoc', kkphimType: sources.kkphim.types.series },

  // ---- Trung Quốc ----
  { id: 'china-movie', name: '🇨🇳 Phim Lẻ Trung Quốc', contentKind: 'movie', strategy: 'country', country: 'trung-quoc', kkphimType: sources.kkphim.types.movie },
  { id: 'china-series', name: '🇨🇳 Phim Bộ Trung Quốc', contentKind: 'series', strategy: 'country', country: 'trung-quoc', kkphimType: sources.kkphim.types.series },

  // ---- Âu Mỹ (chỉ KKPhim, theo yêu cầu gốc — NguonC không được liệt kê cho mục này) ----
  { id: 'west-movie', name: '🎬 Phim Lẻ Âu Mỹ', contentKind: 'movie', strategy: 'country', country: 'au-my', kkphimType: sources.kkphim.types.movie, kkphimOnly: true },
  { id: 'west-series', name: '📺 Phim Bộ Âu Mỹ', contentKind: 'series', strategy: 'country', country: 'au-my', kkphimType: sources.kkphim.types.series, kkphimOnly: true },

  // ---- Thái Lan ----
  { id: 'thai-movie', name: '🇹🇭 Phim Lẻ Thái Lan', contentKind: 'movie', strategy: 'country', country: 'thai-lan', kkphimType: sources.kkphim.types.movie },
  { id: 'thai-series', name: '🇹🇭 Phim Bộ Thái Lan', contentKind: 'series', strategy: 'country', country: 'thai-lan', kkphimType: sources.kkphim.types.series },

  // ---- Anime (TMDB, gốc tiếng Nhật, thể loại Animation=16) ----
  { id: 'anime-movie', name: '⛩️ Anime (Lẻ)', contentKind: 'movie', strategy: 'tmdb', tmdbType: 'movie', tmdbParams: { with_original_language: 'ja', with_genres: '16' } },
  { id: 'anime-series', name: '⛩️ Anime (Bộ)', contentKind: 'series', strategy: 'tmdb', tmdbType: 'tv', tmdbParams: { with_original_language: 'ja', with_genres: '16' } },

  // ---- Hoạt hình trẻ em (TMDB Animation, loại trừ tiếng Nhật để không trùng anime) ----
  // kids-movie bổ sung thêm nguồn KKPhim (type=hoathinh) theo yêu cầu gốc.
  {
    id: 'kids-movie',
    name: '🧸 Hoạt Hình Trẻ Em (Lẻ)',
    contentKind: 'movie',
    strategy: 'tmdb+kkphim',
    tmdbType: 'movie',
    tmdbParams: { with_genres: '16' },
    excludeOriginalLanguage: 'ja',
    kkphimType: sources.kkphim.types.animation,
  },
  {
    id: 'kids-series',
    name: '🧸 Hoạt Hình Trẻ Em (Bộ)',
    contentKind: 'series',
    strategy: 'tmdb',
    tmdbType: 'tv',
    tmdbParams: { with_genres: '16' },
    excludeOriginalLanguage: 'ja',
  },

  // ---- Tài liệu (TMDB Documentary=99) ----
  { id: 'docs-movie', name: '📚 Phim Tài Liệu', contentKind: 'movie', strategy: 'tmdb', tmdbType: 'movie', tmdbParams: { with_genres: '99' } },
  { id: 'docs-series', name: '📚 Tài Liệu (Bộ)', contentKind: 'series', strategy: 'tmdb', tmdbType: 'tv', tmdbParams: { with_genres: '99' } },
];
