// config/sources.js
//
// Toàn bộ URL endpoint + tên field JSON của từng nguồn dữ liệu được gom vào 1 chỗ.
// Nếu KKPhim/NguonC đổi cấu trúc API, chỉ cần sửa Ở ĐÂY — không đụng logic
// fetch/dedupe/build trong src/ và scripts/.
//
// Ghi chú độ tin cậy:
//   [ĐÃ XÁC MINH]   - đọc trực tiếp từ tài liệu chính thức (chụp màn hình 2026-09)
//   [CHƯA XÁC MINH] - suy đoán / lấy từ mô tả gốc, cần bạn tự kiểm tra khi chạy thật

module.exports = {
  kkphim: {
    // [ĐÃ XÁC MINH] https://kkphim.com/api-document
    baseUrl: 'https://phimapi.com',

    endpoints: {
      // Danh sách phim theo loại, lọc được country/category/year/sort_*
      // Ví dụ xác minh: /v1/api/danh-sach/phim-le?country=han-quoc&year=2024
      listByType: (type) => `/v1/api/danh-sach/${type}`,

      // Danh sách phim theo quốc gia (không giới hạn loại)
      // Ví dụ xác minh: /v1/api/quoc-gia/han-quoc?year=2024
      listByCountry: (countrySlug) => `/v1/api/quoc-gia/${countrySlug}`,

      // Danh sách phim theo thể loại
      // Ví dụ xác minh: /v1/api/the-loai/hanh-dong?page=1
      listByCategory: (categorySlug) => `/v1/api/the-loai/${categorySlug}`,

      // Phim mới cập nhật (định dạng v1), không cần slug
      // Ví dụ xác minh: /v1/api/danh-sach?page=1
      listNewest: () => '/v1/api/danh-sach',

      // Chi tiết phim — bản THƯỜNG (không phải v1).
      // [ĐÃ XÁC MINH] có "content" (mô tả), full thumb_url/poster_url, tmdb.id/imdb.id.
      // Lưu ý: response danh sách KHÔNG có field "content" — bắt buộc phải gọi
      // endpoint này cho từng phim để lấy mô tả tiếng Việt.
      detail: (slug) => `/phim/${slug}`,

      listCategories: () => '/the-loai',
      listCountries: () => '/quoc-gia',

      search: () => '/v1/api/tim-kiem',
    },

    // Đường dẫn (dot path) để lấy mảng/obj cần thiết trong JSON trả về.
    fields: {
      listItemsPath: 'data.items',
      detailItemPath: 'data.item',
      categoriesPath: 'data.items',
      countriesPath: 'data.items',
    },

    // [CHƯA XÁC MINH TRỰC TIẾP] domain CDN ảnh.
    // thumb_url/poster_url trả về dạng đường dẫn tương đối
    // (vd "upload/vod/20260123-1/xxxxx.jpg"). Convention phổ biến của các API
    // họ Ophim là https://phimimg.com/ — đã đặt mặc định như vậy.
    // ==> CHẠY `npm run fetch:debug` MỘT LẦN, MỞ THỬ POSTER URL IN RA TRONG LOG.
    //     Nếu ảnh không load, đổi giá trị này là xong, không cần sửa gì khác.
    imageBaseUrl: 'https://phimimg.com/',

    // Country slug — đã xác nhận qua ví dụ chính thức (han-quoc, au-my);
    // 3 slug còn lại suy theo cùng quy luật đặt tên không dấu.
    countrySlugs: {
      'viet-nam': 'viet-nam',
      'han-quoc': 'han-quoc',
      'trung-quoc': 'trung-quoc',
      'thai-lan': 'thai-lan',
      'au-my': 'au-my',
    },

    // type dùng cho /v1/api/danh-sach/{type}
    types: {
      movie: 'phim-le', // [ĐÃ XÁC MINH]
      series: 'phim-bo', // suy theo cặp đối xứng với phim-le, cùng quy luật
      animation: 'hoathinh', // [ĐÃ XÁC MINH] — thấy trực tiếp trong field "type" của item mẫu
      tvshow: 'tv-shows', // [CHƯA XÁC MINH] không dùng tới trong 16 catalog hiện tại
    },
  },

  nguonc: {
    // ĐÃ XÁC NHẬN THỰC TẾ (chạy trên GitHub Actions, 2026-09): NguonC trả 403
    // Forbidden ngay cả sau khi giả header trình duyệt thật (User-Agent, Referer...).
    // Đây là chặn bot cứng kiểu Cloudflare — không thể bypass bằng cách gọi HTTP
    // đơn thuần, chỉ có browser thật chạy JS mới qua được (Puppeteer/Playwright),
    // không hợp với kiến trúc "static addon, chỉ fetch nhẹ" của project này.
    // => TẮT HẲN nguồn này để khỏi phí thời gian retry vô ích mỗi lần chạy.
    // Nếu sau này NguonC gỡ chặn hoặc bạn có cách khác (proxy, browser thật...),
    // đổi `enabled: true` là bật lại được ngay, không cần sửa code khác.
    enabled: false,

    baseUrl: 'https://phim.nguonc.com',

    endpoints: {
      listByCountry: (slug) => `/api/films/quoc-gia/${slug}`,
      detail: (slug) => `/api/film/${slug}`,
    },

    fields: {
      // Code sẽ thử lần lượt từng path này cho tới khi tìm được mảng/obj hợp lệ.
      listItemsPath: ['items', 'movies', 'data.items', 'data.movies'],
      detailItemPath: ['movie', 'item', 'data', 'data.movie', 'data.item'],
    },

    countrySlugs: {
      'viet-nam': 'viet-nam',
      'han-quoc': 'han-quoc',
      'trung-quoc': 'trung-quoc',
      'thai-lan': 'thai-lan',
    },

    // Giữ lại header + retry (phòng khi enabled=true trở lại) dù hiện không dùng tới.
    requestHeaders: {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
      Accept: 'application/json, text/plain, */*',
      'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
      Referer: 'https://phim.nguonc.com/',
      Origin: 'https://phim.nguonc.com',
    },
    retry: { retries: 2, delayMs: 800 },
  },

  tmdb: {
    baseUrl: 'https://api.themoviedb.org/3',
    imageBaseUrl: 'https://image.tmdb.org/t/p/w500',
    backdropBaseUrl: 'https://image.tmdb.org/t/p/w780',
    detailPath: (type, id) => `/${type}/${id}`,
    discoverPath: (type) => `/discover/${type}`,
    // Endpoint ĐÚNG để lấy imdb_id từ tmdb id.
    // KHÔNG dùng /find?external_source=tmdb_id (external_source đó không tồn tại
    // trong TMDB API — /find chỉ nhận imdb_id/tvdb_id/facebook_id/... làm INPUT,
    // không có chiều ngược lại). Cách đúng đã verify: gọi thẳng
    // /movie/{id} hoặc /tv/{id} với append_to_response=external_ids.
    externalIdsAppend: 'external_ids',
  },

  cinemeta: {
    baseUrl: 'https://v3-cinemeta.strem.io',
    metaPath: (type, imdbId) => `/meta/${type}/${imdbId}.json`,
  },
};
