// src/cache.js
// Cache dạng dict {imdbId: metaObject} cho mỗi catalog, lưu ở cache/{catalogId}.json.
// Nhờ key là imdbId nên chạy lại fetch.js nhiều lần KHÔNG tạo trùng dữ liệu
// (idempotent) — record cũ được ghi đè bằng bản mới nếu trùng ID.

const fs = require('fs');
const path = require('path');

const CACHE_DIR = path.join(__dirname, '..', 'cache');

function ensureDir() {
  if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });
}

function loadCatalogCache(catalogId) {
  ensureDir();
  const file = path.join(CACHE_DIR, `${catalogId}.json`);
  if (!fs.existsSync(file)) return {};
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    console.warn(`[warn] cache/${catalogId}.json lỗi parse — bỏ qua, tạo lại từ đầu.`);
    return {};
  }
}

function saveCatalogCache(catalogId, dict) {
  ensureDir();
  const file = path.join(CACHE_DIR, `${catalogId}.json`);
  fs.writeFileSync(file, JSON.stringify(dict, null, 2), 'utf8');
}

module.exports = { loadCatalogCache, saveCatalogCache };
