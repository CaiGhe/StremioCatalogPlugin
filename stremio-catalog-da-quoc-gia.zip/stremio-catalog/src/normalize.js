// src/normalize.js
// Chuyển 1 "candidate" (từ kkphim/nguonc/tmdb) thành Stremio meta preview object.
// Xem: https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/api/responses/meta.md

function toStremioMeta(candidate, contentKind) {
  if (!candidate || !candidate.imdbId) return null; // không có IMDb ID thật -> loại

  const type = contentKind === 'series' ? 'series' : 'movie';
  const meta = {
    id: candidate.imdbId,
    type,
    name: candidate.name || candidate.originName || candidate.imdbId,
  };

  if (candidate.poster) meta.poster = candidate.poster;
  if (candidate.background) meta.background = candidate.background;
  if (candidate.content) meta.description = candidate.content;
  if (candidate.year) meta.releaseInfo = String(candidate.year);
  if (candidate.voteAverage) meta.imdbRating = String(candidate.voteAverage);

  return meta;
}

module.exports = { toStremioMeta };
