// src/dedupe.js
// Gộp nhiều candidate cùng imdbId thành 1, ưu tiên bản có mô tả + poster tốt hơn
// (ưu tiên mô tả tiếng Việt từ KKPhim/NguonC theo yêu cầu).

function score(candidate) {
  let s = 0;
  if (candidate.content && candidate.content.length > 20) s += 2;
  if (candidate.poster) s += 1;
  if (candidate.source === 'kkphim' || candidate.source === 'nguonc') s += 1;
  return s;
}

function dedupeByImdb(candidates) {
  const map = new Map();
  for (const c of candidates) {
    if (!c || !c.imdbId) continue;
    const existing = map.get(c.imdbId);
    if (!existing || score(c) > score(existing)) {
      map.set(c.imdbId, c);
    }
  }
  return [...map.values()];
}

module.exports = { dedupeByImdb };
