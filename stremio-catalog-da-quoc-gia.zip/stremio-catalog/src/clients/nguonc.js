// src/clients/nguonc.js
//
// Client cho NguonC (https://phim.nguonc.com).
// [CHƯA XÁC MINH TRỰC TIẾP] — trang api-document chặn bot nên không đọc được.
// Code này CỐ Ý dò nhiều tên field/path phổ biến (xem config/sources.js#nguonc.fields)
// để giảm rủi ro vỡ hoàn toàn nếu tên field thực tế khác đôi chút.
//
// Nếu chạy `npm run fetch:debug` mà thấy log "[warn][nguonc]" liên tục — nghĩa là
// cấu trúc thực tế khác nhiều so với giả định, cần mở /api-document trên máy bạn,
// copy 1 response mẫu, rồi sửa lại object `fields` trong config/sources.js.

const { fetchJson } = require('../lib/http');
const cfg = require('../../config/sources').nguonc;

function pickFirst(obj, dotPaths) {
  for (const p of dotPaths) {
    const val = p.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
    if (val !== undefined) return val;
  }
  return undefined;
}

function stripHtml(html) {
  return String(html || '')
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeImdb(raw) {
  if (!raw) return null;
  const s = String(raw).trim();
  if (!s) return null;
  return s.startsWith('tt') ? s : `tt${s}`;
}

async function listByCountry(countrySlug, opts = {}) {
  if (cfg.enabled === false) {
    throw new Error('NguonC đang tắt trong config/sources.js (đã xác nhận bị chặn 403 từ môi trường server) — bỏ qua, dùng KKPhim.');
  }
  const { page = 1 } = opts;
  const url = `${cfg.baseUrl}${cfg.endpoints.listByCountry(countrySlug)}?page=${page}`;
  const json = await fetchJson(url, { headers: cfg.requestHeaders, ...cfg.retry });
  const items = pickFirst(json, cfg.fields.listItemsPath);
  return Array.isArray(items) ? items : [];
}

async function getDetail(slug) {
  if (cfg.enabled === false) {
    throw new Error('NguonC đang tắt trong config/sources.js.');
  }
  const url = `${cfg.baseUrl}${cfg.endpoints.detail(slug)}`;
  const json = await fetchJson(url, { headers: cfg.requestHeaders, ...cfg.retry });
  const item = pickFirst(json, cfg.fields.detailItemPath);
  if (!item) return null;

  const imdbRaw = item.imdb_id ?? item.imdb ?? item.imdbId ?? null;

  return {
    source: 'nguonc',
    slug: item.slug || slug,
    name: item.name || null,
    originName: item.original_name || item.origin_name || null,
    content: stripHtml(item.description || item.content),
    year: item.year || item.publish_year || null,
    imdbId: normalizeImdb(imdbRaw),
    poster: item.poster_url || item.thumb_url || null,
    background: item.thumb_url || item.poster_url || null,
    currentEpisode: item.current_episode ?? null,
    totalEpisodes: item.total_episodes ?? null,
  };
}

module.exports = { listByCountry, getDetail };
