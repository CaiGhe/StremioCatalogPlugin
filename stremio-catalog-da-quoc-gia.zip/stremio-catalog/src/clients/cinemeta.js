// src/clients/cinemeta.js
// Dùng để xác thực IMDb ID còn "sống" + lấp poster/mô tả/điểm nếu nguồn chính thiếu.

const { fetchJson } = require('../lib/http');
const cfg = require('../../config/sources').cinemeta;

async function getMeta(type, imdbId) {
  try {
    const url = `${cfg.baseUrl}${cfg.metaPath(type, imdbId)}`;
    const json = await fetchJson(url, { retries: 1, delayMs: 300 });
    return (json && json.meta) || null;
  } catch {
    return null; // không tồn tại / lỗi mạng -> coi như không xác thực được, bỏ qua an toàn
  }
}

module.exports = { getMeta };
