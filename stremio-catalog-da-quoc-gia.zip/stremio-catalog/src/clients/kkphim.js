// src/clients/kkphim.js
// Client cho KKPhim (https://phimapi.com) — đã xác minh qua tài liệu chính thức.

const { fetchJson } = require('../lib/http');
const cfg = require('../../config/sources').kkphim;

function pick(obj, dotPath) {
  return dotPath.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

function stripHtml(html) {
  return String(html || '')
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function resolveImageUrl(relPath) {
  if (!relPath) return null;
  if (/^https?:\/\//i.test(relPath)) return relPath;
  return cfg.imageBaseUrl.replace(/\/+$/, '') + '/' + String(relPath).replace(/^\/+/, '');
}

// Danh sách phim theo loại (phim-le/phim-bo/hoathinh) + lọc theo quốc gia.
// countrySlug có thể để null để lấy không giới hạn quốc gia (dùng cho hoathinh).
async function listByTypeAndCountry(type, countrySlug, opts = {}) {
  const { page = 1, year, sortField = 'modified.time', sortType = 'desc' } = opts;
  const params = new URLSearchParams({
    page: String(page),
    sort_field: sortField,
    sort_type: sortType,
  });
  if (countrySlug) params.set('country', countrySlug);
  if (year) params.set('year', String(year));

  const url = `${cfg.baseUrl}${cfg.endpoints.listByType(type)}?${params.toString()}`;
  const json = await fetchJson(url);
  return pick(json, cfg.fields.listItemsPath) || [];
}

// Chi tiết phim theo slug — nguồn duy nhất có "content" (mô tả) + ảnh full path + tmdb.id.
async function getDetail(slug) {
  const url = `${cfg.baseUrl}${cfg.endpoints.detail(slug)}`;
  const json = await fetchJson(url);
  const item = pick(json, cfg.fields.detailItemPath);
  if (!item) return null;

  return {
    source: 'kkphim',
    slug: item.slug || slug,
    name: item.name || null,
    originName: item.origin_name || null,
    content: stripHtml(item.content),
    year: item.year || null,
    tmdbId: (item.tmdb && item.tmdb.id) || null,
    tmdbType: (item.tmdb && item.tmdb.type) || null, // 'movie' | 'tv'
    poster: resolveImageUrl(item.poster_url || item.thumb_url),
    background: resolveImageUrl(item.thumb_url || item.poster_url),
    categories: Array.isArray(item.category) ? item.category.map((c) => c.name) : [],
    countries: Array.isArray(item.country) ? item.country.map((c) => c.name) : [],
    type: item.type || null,
  };
}

async function listCategories() {
  const url = `${cfg.baseUrl}${cfg.endpoints.listCategories()}`;
  const json = await fetchJson(url);
  return pick(json, cfg.fields.categoriesPath) || [];
}

async function listCountries() {
  const url = `${cfg.baseUrl}${cfg.endpoints.listCountries()}`;
  const json = await fetchJson(url);
  return pick(json, cfg.fields.countriesPath) || [];
}

module.exports = {
  listByTypeAndCountry,
  getDetail,
  listCategories,
  listCountries,
  resolveImageUrl,
  stripHtml,
};
