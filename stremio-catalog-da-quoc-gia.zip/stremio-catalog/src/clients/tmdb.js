// src/clients/tmdb.js
const { fetchJson } = require('../lib/http');
const cfg = require('../../config/sources').tmdb;

function buildUrl(path, params, apiKey) {
  const usp = new URLSearchParams({ api_key: apiKey, ...params });
  return `${cfg.baseUrl}${path}?${usp.toString()}`;
}

async function discover(type, apiKey, extraParams = {}, page = 1) {
  const url = buildUrl(
    cfg.discoverPath(type),
    { sort_by: 'popularity.desc', language: 'vi-VN', page: String(page), ...extraParams },
    apiKey
  );
  const json = await fetchJson(url);
  return json.results || [];
}

// 1 lần gọi lấy: mô tả tiếng Việt, poster ưu tiên tiếng Việt, imdb_id.
// Trả về null nếu không tìm được imdb_id (theo quy tắc bắt buộc: không có IMDb ID -> loại).
async function getDetailWithImdb(type, tmdbId, apiKey) {
  const url = buildUrl(
    cfg.detailPath(type, tmdbId),
    {
      language: 'vi-VN',
      append_to_response: `images,${cfg.externalIdsAppend}`,
      include_image_language: 'vi,en,null',
    },
    apiKey
  );
  const json = await fetchJson(url);

  const imdbId = json?.external_ids?.imdb_id || null;
  if (!imdbId) return null;

  let overview = json.overview;
  if (!overview) {
    // Mô tả tiếng Việt rỗng -> fallback tiếng Anh (1 request phụ, chỉ khi cần)
    try {
      const enUrl = buildUrl(cfg.detailPath(type, tmdbId), { language: 'en-US' }, apiKey);
      const enJson = await fetchJson(enUrl, { retries: 1 });
      overview = enJson.overview || '';
    } catch {
      overview = '';
    }
  }

  const posters = json?.images?.posters || [];
  const viPoster = posters.find((p) => p.iso_639_1 === 'vi');
  const posterPath = (viPoster && viPoster.file_path) || json.poster_path || null;

  return {
    source: 'tmdb',
    tmdbId,
    imdbId,
    name: type === 'tv' ? json.name : json.title,
    originName: type === 'tv' ? json.original_name : json.original_title,
    content: overview || '',
    year: (json.release_date || json.first_air_date || '').slice(0, 4) || null,
    poster: posterPath ? `${cfg.imageBaseUrl}${posterPath}` : null,
    background: json.backdrop_path ? `${cfg.backdropBaseUrl}${json.backdrop_path}` : null,
    voteAverage: json.vote_average || null,
    originalLanguage: json.original_language || null,
  };
}

module.exports = { discover, getDetailWithImdb };
