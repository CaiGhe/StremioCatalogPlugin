#!/usr/bin/env node
// scripts/fetch.js
//
// Fetch dữ liệu cho toàn bộ 16 catalog, ghi vào cache/{catalogId}.json.
// Chạy: node scripts/fetch.js          (bình thường)
//       node scripts/fetch.js --debug  (in thêm mẫu dữ liệu để kiểm tra field)
//
// Idempotent: cache key theo imdbId nên chạy lại nhiều lần không tạo trùng.

const { loadEnv } = require('./loadEnv');
loadEnv();

const catalogs = require('../config/catalogs');
const kkphim = require('../src/clients/kkphim');
const nguonc = require('../src/clients/nguonc');
const tmdb = require('../src/clients/tmdb');
const { dedupeByImdb } = require('../src/dedupe');
const { toStremioMeta } = require('../src/normalize');
const { loadCatalogCache, saveCatalogCache } = require('../src/cache');

const TARGET_PER_CATALOG = Number(process.env.ITEMS_PER_CATALOG || 50);
const MAX_PAGES = 3; // đủ dư ứng viên sau khi lọc bớt phim không có IMDb ID
const TMDB_API_KEY = process.env.TMDB_API_KEY || '';
const DEBUG = process.argv.includes('--debug');

function log(...args) {
  console.log(...args);
}

function mapTmdbType(kkphimTmdbType, contentKind) {
  if (kkphimTmdbType === 'movie' || kkphimTmdbType === 'tv') return kkphimTmdbType;
  return contentKind === 'series' ? 'tv' : 'movie';
}

// ---- Chiến lược "country": KKPhim (bắt buộc) + NguonC (nếu có) ----
async function fetchCountryCatalog(cat) {
  if (!TMDB_API_KEY) {
    console.warn(
      `[warn][tmdb] Thiếu TMDB_API_KEY — catalog "${cat.id}" gần như chắc chắn sẽ ra 0 phim, ` +
        `vì KKPhim không tự cho IMDb ID đáng tin (thường null), phải tra qua TMDB mới suy ra được.`
    );
  }
  const candidates = [];
  const enoughCandidates = () => candidates.length >= TARGET_PER_CATALOG * 2;

  // KKPhim
  for (let page = 1; page <= MAX_PAGES && !enoughCandidates(); page++) {
    let items = [];
    try {
      items = await kkphim.listByTypeAndCountry(cat.kkphimType, cat.country, { page });
    } catch (err) {
      console.warn(`[warn][kkphim] Dừng lấy trang ${page} cho ${cat.id}: ${err.message}`);
      break;
    }
    if (!items.length) break;

    for (const it of items) {
      if (!it.slug) continue;
      try {
        const detail = await kkphim.getDetail(it.slug);
        if (!detail || !detail.tmdbId) continue; // không có tmdb id -> không suy ra imdb được -> bỏ

        const withImdb = await tmdb.getDetailWithImdb(
          mapTmdbType(detail.tmdbType, cat.contentKind),
          detail.tmdbId,
          TMDB_API_KEY
        );
        if (!withImdb) continue; // không có imdb_id thật -> LOẠI theo quy tắc bắt buộc

        candidates.push({
          ...withImdb,
          // Ưu tiên tên/mô tả/ảnh tiếng Việt gốc từ KKPhim hơn TMDB
          name: detail.name || withImdb.name,
          content: detail.content || withImdb.content,
          poster: detail.poster || withImdb.poster,
          background: detail.background || withImdb.background,
        });
      } catch (err) {
        console.warn(`[warn][kkphim-detail] slug=${it.slug}: ${err.message}`);
      }
      if (enoughCandidates()) break;
    }
  }

  // NguonC (bỏ qua với catalog đánh dấu kkphimOnly, ví dụ Âu Mỹ)
  if (!cat.kkphimOnly) {
    for (let page = 1; page <= MAX_PAGES && !enoughCandidates(); page++) {
      let items = [];
      try {
        items = await nguonc.listByCountry(cat.country, { page });
      } catch (err) {
        console.warn(`[warn][nguonc] Nguồn lỗi/không phản hồi cho ${cat.id}: ${err.message} — bỏ qua NguonC, dùng KKPhim.`);
        break;
      }
      if (!items.length) break;

      for (const it of items) {
        const slug = it.slug || it.alias;
        if (!slug) continue;
        try {
          const detail = await nguonc.getDetail(slug);
          if (!detail || !detail.imdbId) continue;
          candidates.push(detail);
        } catch (err) {
          console.warn(`[warn][nguonc-detail] slug=${slug}: ${err.message}`);
        }
        if (enoughCandidates()) break;
      }
    }
  }

  return candidates;
}

// ---- Chiến lược "tmdb": lấy hoàn toàn từ TMDB discover ----
async function fetchTmdbCatalog(cat) {
  if (!TMDB_API_KEY) {
    console.warn(`[warn][tmdb] Thiếu TMDB_API_KEY trong .env — bỏ qua catalog "${cat.id}".`);
    return [];
  }
  const candidates = [];
  const enoughCandidates = () => candidates.length >= TARGET_PER_CATALOG * 2;

  for (let page = 1; page <= MAX_PAGES && !enoughCandidates(); page++) {
    let results = [];
    try {
      results = await tmdb.discover(cat.tmdbType, TMDB_API_KEY, cat.tmdbParams, page);
    } catch (err) {
      console.warn(`[warn][tmdb-discover] ${cat.id} trang ${page}: ${err.message}`);
      break;
    }
    if (!results.length) break;

    for (const r of results) {
      if (cat.excludeOriginalLanguage && r.original_language === cat.excludeOriginalLanguage) continue;
      try {
        const detail = await tmdb.getDetailWithImdb(cat.tmdbType, r.id, TMDB_API_KEY);
        if (!detail) continue;
        candidates.push(detail);
      } catch (err) {
        console.warn(`[warn][tmdb-detail] id=${r.id}: ${err.message}`);
      }
      if (enoughCandidates()) break;
    }
  }
  return candidates;
}

// ---- Bổ sung KKPhim (hoathinh) cho catalog kids-movie ----
async function fetchKidsKkphimSupplement(cat) {
  if (!cat.kkphimType) return [];
  const candidates = [];
  try {
    for (let page = 1; page <= 2; page++) {
      const items = await kkphim.listByTypeAndCountry(cat.kkphimType, null, { page });
      if (!items.length) break;
      for (const it of items) {
        if (!it.slug) continue;
        const detail = await kkphim.getDetail(it.slug);
        if (!detail || !detail.tmdbId) continue;
        const withImdb = await tmdb.getDetailWithImdb('movie', detail.tmdbId, TMDB_API_KEY);
        if (!withImdb) continue;
        candidates.push({
          ...withImdb,
          name: detail.name || withImdb.name,
          content: detail.content || withImdb.content,
          poster: detail.poster || withImdb.poster,
        });
      }
    }
  } catch (err) {
    console.warn(`[warn][kkphim-hoathinh] ${err.message}`);
  }
  return candidates;
}

async function run() {
  for (const cat of catalogs) {
    log(`\n=== Đang fetch: ${cat.name} (${cat.id}) ===`);
    let candidates = [];

    if (cat.strategy === 'country') {
      candidates = await fetchCountryCatalog(cat);
    } else if (cat.strategy === 'tmdb') {
      candidates = await fetchTmdbCatalog(cat);
    } else if (cat.strategy === 'tmdb+kkphim') {
      candidates = await fetchTmdbCatalog(cat);
      candidates = candidates.concat(await fetchKidsKkphimSupplement(cat));
    } else {
      console.warn(`[warn] Không rõ strategy "${cat.strategy}" cho catalog ${cat.id} — bỏ qua.`);
      continue;
    }

    const deduped = dedupeByImdb(candidates);
    const metas = deduped.map((c) => toStremioMeta(c, cat.contentKind)).filter(Boolean);

    const cache = loadCatalogCache(cat.id);
    for (const m of metas) cache[m.id] = m;
    saveCatalogCache(cat.id, cache);

    log(`-> ${cat.id}: ${metas.length} phim fetch được lần này, tổng cache: ${Object.keys(cache).length}`);
    if (DEBUG && metas[0]) {
      log('   Mẫu meta:', JSON.stringify(metas[0], null, 2));
      if (metas[0].poster) log('   Kiểm tra poster URL bằng cách mở link này trên trình duyệt:', metas[0].poster);
    }
    if (Object.keys(cache).length < 10) {
      console.warn(`   [cảnh báo] Catalog "${cat.id}" hiện chỉ có ${Object.keys(cache).length} phim (<10). Chạy lại hoặc kiểm tra nguồn.`);
    }
  }

  log('\nHoàn tất fetch. Chạy `npm run build` để xuất catalog JSON ra thư mục public/.');
}

run().catch((err) => {
  console.error('\nLỗi không xử lý được:', err);
  process.exit(1);
});
