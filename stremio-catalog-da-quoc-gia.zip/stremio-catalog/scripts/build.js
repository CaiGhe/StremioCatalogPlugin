#!/usr/bin/env node
// scripts/build.js
//
// Đọc cache/{catalogId}.json (đã fetch từ trước), xuất ra:
//   public/manifest.json
//   public/catalog/{type}/{id}.json
// Đúng theo giao thức Stremio static addon — dán URL manifest.json là dùng được.

const fs = require('fs');
const path = require('path');

const { loadEnv } = require('./loadEnv');
loadEnv();

const catalogs = require('../config/catalogs');
const { loadCatalogCache } = require('../src/cache');

const ITEMS_PER_CATALOG = Number(process.env.ITEMS_PER_CATALOG || 50);
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function buildManifest() {
  return {
    id: 'org.duytam1711.staticmoviecatalog',
    version: '1.0.0',
    name: 'Phim Đa Quốc Gia (Static Catalog)',
    description:
      'Danh mục phim theo quốc gia — Việt Nam, Hàn Quốc, Trung Quốc, Âu Mỹ, Thái Lan, Anime, Hoạt hình trẻ em, Tài liệu. Chỉ catalog, không chứa stream.',
    resources: ['catalog'],
    types: ['movie', 'series'],
    catalogs: catalogs.map((c) => ({ type: c.contentKind, id: c.id, name: c.name })),
    idPrefixes: ['tt'],
  };
}

function run() {
  ensureDir(PUBLIC_DIR);
  ensureDir(path.join(PUBLIC_DIR, 'catalog'));

  const manifest = buildManifest();
  fs.writeFileSync(path.join(PUBLIC_DIR, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  console.log('Đã ghi public/manifest.json');

  let anyMissing = false;

  for (const cat of catalogs) {
    const cache = loadCatalogCache(cat.id);
    const metas = Object.values(cache).slice(0, ITEMS_PER_CATALOG);

    if (metas.length < 10) {
      console.warn(`[cảnh báo] "${cat.id}" chỉ có ${metas.length} phim (yêu cầu tối thiểu 10). Chạy lại "npm run fetch" hoặc kiểm tra nguồn.`);
      anyMissing = true;
    }

    const dir = path.join(PUBLIC_DIR, 'catalog', cat.contentKind);
    ensureDir(dir);
    const file = path.join(dir, `${cat.id}.json`);

    // JSON.stringify không bao giờ sinh trailing comma -> luôn parse được.
    fs.writeFileSync(file, JSON.stringify({ metas }, null, 2), 'utf8');
    console.log(`Đã ghi ${path.relative(process.cwd(), file)} (${metas.length} phim)`);
  }

  console.log('\nHoàn tất build. Thư mục public/ sẵn sàng deploy lên GitHub Pages.');
  if (anyMissing) {
    console.log('LƯU Ý: một vài catalog chưa đủ 10 phim — xem cảnh báo phía trên.');
  }
}

run();
