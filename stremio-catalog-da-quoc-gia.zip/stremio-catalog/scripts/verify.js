#!/usr/bin/env node
// scripts/verify.js
//
// Chạy checklist kiểm tra trước khi coi là hoàn thành:
//  1. Gọi thử từng API nguồn, in 1 sample response
//  2. Mỗi catalog có >=10 phim sau khi lọc IMDb
//  3. Validate cấu trúc manifest.json cơ bản
//  4. Gợi ý kiểm tra 1 IMDb ID ngẫu nhiên trên imdb.com
// (File JSON parse được là hiển nhiên vì dùng JSON.stringify khi ghi.)

const fs = require('fs');
const path = require('path');

const { loadEnv } = require('./loadEnv');
loadEnv();

const catalogs = require('../config/catalogs');
const kkphim = require('../src/clients/kkphim');
const nguonc = require('../src/clients/nguonc');
const tmdb = require('../src/clients/tmdb');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const TMDB_API_KEY = process.env.TMDB_API_KEY || '';

function short(obj) {
  return JSON.stringify(obj, null, 2).slice(0, 500);
}

async function checkSampleResponses() {
  console.log('\n== 1. Gọi thử từng API nguồn ==');

  try {
    const list = await kkphim.listByTypeAndCountry('phim-le', 'han-quoc', { page: 1 });
    console.log(`[kkphim] danh-sach/phim-le?country=han-quoc -> ${list.length} phim. Mẫu:\n${short(list[0])}`);
  } catch (err) {
    console.error('[kkphim] LỖI:', err.message);
  }

  try {
    const list = await nguonc.listByCountry('han-quoc', { page: 1 });
    console.log(`[nguonc] films/quoc-gia/han-quoc -> ${list.length} phim. Mẫu:\n${short(list[0])}`);
  } catch (err) {
    console.error('[nguonc] LỖI (có thể do field/endpoint trong config/sources.js chưa đúng thực tế):', err.message);
  }

  if (TMDB_API_KEY) {
    try {
      const results = await tmdb.discover('movie', TMDB_API_KEY, { with_genres: '16' }, 1);
      console.log(`[tmdb] discover/movie genre=16 -> ${results.length} phim. Mẫu:\n${short(results[0])}`);
    } catch (err) {
      console.error('[tmdb] LỖI:', err.message);
    }
  } else {
    console.warn('[tmdb] Bỏ qua — thiếu TMDB_API_KEY trong .env');
  }
}

function checkCatalogCounts() {
  console.log('\n== 2. Kiểm tra số lượng phim mỗi catalog (>=10) ==');
  let allOk = true;
  for (const cat of catalogs) {
    const file = path.join(PUBLIC_DIR, 'catalog', cat.contentKind, `${cat.id}.json`);
    if (!fs.existsSync(file)) {
      console.warn(`  [THIẾU FILE] ${cat.id} — chạy "npm run build" trước`);
      allOk = false;
      continue;
    }
    let data;
    try {
      data = JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (err) {
      console.error(`  [JSON LỖI] ${cat.id}: ${err.message}`);
      allOk = false;
      continue;
    }
    const ok = Array.isArray(data.metas) && data.metas.length >= 10;
    console.log(`  ${ok ? 'OK  ' : 'THIẾU'} ${cat.id}: ${data.metas ? data.metas.length : 0} phim`);
    if (!ok) allOk = false;
  }
  return allOk;
}

function checkManifest() {
  console.log('\n== 3. Kiểm tra manifest.json ==');
  const file = path.join(PUBLIC_DIR, 'manifest.json');
  if (!fs.existsSync(file)) {
    console.error('  Thiếu public/manifest.json — chạy "npm run build" trước');
    return false;
  }
  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (err) {
    console.error('  manifest.json không parse được:', err.message);
    return false;
  }
  const requiredKeys = ['id', 'version', 'name', 'resources', 'types', 'catalogs'];
  const missing = requiredKeys.filter((k) => !(k in manifest));
  if (missing.length) {
    console.error('  Thiếu field bắt buộc:', missing.join(', '));
    return false;
  }
  console.log(`  OK — ${manifest.catalogs.length} catalogs, types: ${manifest.types.join(', ')}`);
  console.log('  Validate kỹ hơn (tuỳ chọn): dán URL manifest.json sau khi deploy vào https://stremio-addon-sdk.netlify.app');
  return true;
}

function suggestRandomImdbCheck() {
  console.log('\n== 4. Gợi ý kiểm tra IMDb ID ngẫu nhiên ==');
  for (const cat of catalogs) {
    const file = path.join(PUBLIC_DIR, 'catalog', cat.contentKind, `${cat.id}.json`);
    if (!fs.existsSync(file)) continue;
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!data.metas || !data.metas.length) continue;
    const sample = data.metas[Math.floor(Math.random() * data.metas.length)];
    console.log(`  [${cat.id}] Mở thử: https://www.imdb.com/title/${sample.id}/  (phim: "${sample.name}")`);
    return;
  }
  console.log('  Chưa có catalog nào để gợi ý — chạy fetch + build trước.');
}

async function run() {
  await checkSampleResponses();
  const countsOk = checkCatalogCounts();
  const manifestOk = checkManifest();
  suggestRandomImdbCheck();

  console.log('\n== Kết quả tổng ==');
  console.log(countsOk && manifestOk ? 'PASS — tất cả kiểm tra cơ bản đều ổn.' : 'CÓ VẤN ĐỀ — xem cảnh báo/lỗi ở trên.');
}

run();
